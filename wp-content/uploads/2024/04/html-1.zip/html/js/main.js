$(document).ready(function () {
  $("section.banner-slider123").slick({
    dots: true,
    infinite: true,
    speed: 300,
    nextArrow:true,
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: true,
    prevArrow: $(".icon-main-asidew .slide-prev"),
    nextArrow: $(".icon-main-asidew .slide-next"),
  });

  const items = document.querySelectorAll(".accordion button");

function toggleAccordion() {
  const itemToggle = this.getAttribute('aria-expanded');
  
  for (i = 0; i < items.length; i++) {
    items[i].setAttribute('aria-expanded', 'false');
  }
  
  if (itemToggle == 'false') {
    this.setAttribute('aria-expanded', 'true');
  }
}

items.forEach(item => item.addEventListener('click', toggleAccordion));
});




